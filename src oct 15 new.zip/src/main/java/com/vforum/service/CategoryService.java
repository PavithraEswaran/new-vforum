package com.vforum.service;

import com.vforum.model.Category;

public interface CategoryService {
	public Category getCategoryById(int categoryId);
}
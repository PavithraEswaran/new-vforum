package com.vforum.service;

	
	
	
	import java.util.List;

import com.vforum.model.Employee;
	 
	
	 
	public interface EmployeeService {
	     
	    public void addEmployee(Employee employee);
	 
	    public List<Employee> getAllEmployees();
    
	    public Employee getEmployee(int employeeid);
	 
	   
	}